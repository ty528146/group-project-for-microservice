var express = require('express');
var router = express.Router();
var bcrypt = require('bcrypt');
var passport = require('passport');
const jwt = require('jsonwebtoken');
const saltRounds = 10;
const checkAuth = require('../middleware/security');
/* GET home page. */
var expressValidator = require('express-validator');
///1107
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

router.post('/customer/profile', function(req, res, next) {
    //console.log("============this is user id========");
    //console.log(req.cookie.user_id)
    try{
        console.log("============this is user id========");
        console.log(req.cookies.user_id);

    }
    catch(error){
        console.log("============this is user error========");
        console.log(error);

    }
    //var uid = req.user.user_id;
    var uid = req.cookies.user_id;
    var income = req.body.income;
    var height = req.body.height;
    var street = req.body.street;
    var state = req.body.state;
    var telephone = req.body.telephone;
    var zipcode = req.body.zipcode;
    var age = req.body.age;
    var xhr = new XMLHttpRequest();
    console.log("this is age"+age);
    xhr.open('POST', 'https://d6cerdp2bi.execute-api.us-east-1.amazonaws.com/dev/compare-yourself');
    xhr.onload = function(e) {
        if (this.status == 200) {
            //console.log(this);
            var result = JSON.parse(this.responseText);
            //console.log( result); // JSON response
            console.log(typeof(result));
            console.log(result);
            res.send(result);
        }
    };
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'allow');//deny//asdfjal
    console.log({age: +age, height: +height, income: +income,state:state,street:street,telephone:telephone,zipcode:zipcode,userid:uid});
    //{ errorMessage: 'One or more parameter values were invalid: An AttributeValue may not contain an empty string',
    //   errorType: 'ValidationException',
    //   stackTrace:
    //must match all database require or will error like abve
    xhr.send(JSON.stringify({age: +age, height: +height, income: +income,state:state,street:street,telephone:telephone,zipcode:zipcode,userid:uid}));
    ///console.log(result);
   // res.send(result);//send back to server
});


//1108
router.get('/customer/profile/registered', function(req, res, next) {
    // try{
    //     var uid = "user_id"+req.cookie.user_id;
    // }
    // catch(error){
    //     console.log("================*******************#################");
    // }
    // var uid = "user_id1";
    // try{
    //     console.log(req.cookies.user_id);
    // }catch(error){
    //     console.log(err);
    // }
   // var uid = "user_id"+req.cookies.user_id;
    try{
        var uid = req.cookies.user_id;
        //console.log("================*******************#################");
        console.log(uid);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'https://d6cerdp2bi.execute-api.us-east-1.amazonaws.com/dev/compare-yourself/single');
        xhr.onload = function(e) {
            if (this.status == 200) {
                //console.log(this);
                var result = JSON.parse(this.responseText);
                if(result.statusCode == 200) {
                    //console.log( result); // JSON response
                    console.log(typeof(result));
                    console.log(result);
                    var age = result.age;
                    var income = result.income;
                    var state = result.state;
                    var zipcode = result.zipcode;
                    var street = result.street;
                    var telephone = result.telephone;
                    res.render('customer/profileshow', {
                        userid: uid,
                        age: age,
                        income: income,
                        zipcode: zipcode,
                        street: street,
                        telephone: telephone,
                        state: state
                    });
                }else{
                    res.redirect('/customer/profile');
                }
            }
        };
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('Authorization', 'allow');//deny//asdfjal
        xhr.send(JSON.stringify({userid:uid}));
        ///console.log(result);
        // res.send(result);//send back to server
    }
    catch(error){
        console.log("hhhhh");
    }
    ///console.log(result);
    // res.send(result);//send back to server
});

///1106
router.get('/profile/:userid', function(req, res, next) {
        const id = req.params.userid;
        if(id === "38"){
            res.status(200).json({
                message:'this is my first try',
                id : id
            })
        }else{
            res.status(200).json({
                message:'this is my first try',
                id : id
            })
        }

});
//1106
router.patch('/profile/:userid', function(req, res, next) {
    res.status(200).json({
        message:'this is a patch method',
        id : id
    })
});

router.delete('/profile/:userid', function(req, res, next) {
    res.status(200).json({
        message:'this is a delete method',
        id : id
    })
});

///////
router.get('/', function(req, res, next) {
    console.log(req.user);//associated with pass port
    console.log(req.isAuthenticated());//passport
    res.redirect('/shopping');
});
router.get('/shopping', function(req, res, next) {
    res.render('index', { title: 'Quick Shopping' });
});
router.get('/customer/profile',checkAuth,function(req,res,next){
    res.render('customer/profile', {title:"PROFILE succeed"});
});
//comment out 1108
// router.get('/login/fail',authenticationMiddleware(),function(req,res,next){
//     res.redirect('/');
// });
//comment out 1108
// router.get('/register/fail',authenticationMiddleware(),function(req,res,next){
//     res.render('index', { title: 'registration fails' });
// });
//comment out 1108
// router.get('/customer/login',authenticationMiddleware(), function(req, res, next) {
//     console.log(req.user);
//     console.log(req.isAuthenticated());
//     res.render('index', { title: 'success' });
// });
 router.get('/customer/register', function(req, res, next){
   res.render('customer/register', {title:"register", balala: 'Registration'});
 });

router.get('/logout',function(req,res,next){
    req.logout();//only log out at the app need to clear the session in our database as well
    //1108 comment out
    //req.session.destroy();
    res.locals.isAuthenticated = false;
    res.cookie('auth','i just want to log out');//req.clearCookie("auth");
    res.render('customer/register', {title:"register", balala: 'Registration'});
    //res.redirect('/');
})
 router.post('/customer/register', function(req, res, next){
     //req.checkBody('username','username should be 3-100 characters long').len(3,100);
     req.checkBody('email','email should be 3-100 characters long').len(3,100);//SECONDE IS ERROR MESSAGE
     req.checkBody('email','email should be valid').isEmail();
     req.checkBody('password','email should be 3-100 characters long').len(3,100);
     req.checkBody('repassword','password do not match').equals(req.body.password);
    const errors = req.validationErrors();
   if (errors) {
       console.log(`errors: ${JSON.stringify(errors)}`);
         res.render('customer/register', {
           title: 'Registration Fails!',
             errors: errors
         });

   }else{
       const email = req.body.email;
       const password = req.body.password;
       const username = req.body.username;
       const db = require('../db.js');
       bcrypt.hash(password, saltRounds, function(err, hash) {
           console.log(hash);
           // Store hash in your password DB.
           db.query('INSERT INTO new_user (username, email, password) VALUES (?,?,?)',[username, email, hash],
               function(error, results, fields) {if (error) throw error});
           //res.render('customer/register', {title: 'Registration Success'});

           db.query('SELECT LAST_INSERT_ID() as user_id',function(error,result,fields){//just inser into the db
               // login in the user the create the session only when create using  form
               if(error) throw error;
               //result contain the user id just insert into the user database
               const user_id = result[0];
               console.log(result[0]);//
               //login come from pasport
               req.login(user_id,function(error){//login from passport
                   res.redirect('/');//creata a session and cookies for user login the user using the ser id
                   //prompt('succesfully register!');
               });
               //res.render('customer/login', {title: 'Registration Success'});
           });
           //res.render('customer/login', {title: 'Registration Success'});
           console.log("success!");
       });
       // db.query('INSERT INTO users (username, email, password) VALUES (?,?,?)',[username, email, password],
       //     function(error, results, fields) {if (error) throw error});
       // //res.render('customer/register', {title: 'Registration Success'});
       // res.redirect('/');
   }
     // const email = req.body.email;
     // const password = req.body.password;
     // const username = req.body.username;
     // const db = require('../db.js');
     // bcrypt.hash(password, saltRounds, function(err, hash) {
     //     console.log(hash);
     //     // Store hash in your password DB.
     //     db.query('INSERT INTO new_user (username, email, password) VALUES (?,?,?)',[username, email, hash],
     //         function(error, results, fields) {if (error) throw error});
     //     //res.render('customer/register', {title: 'Registration Success'});
     //
     //     db.query('SELECT LAST_INSERT_ID() as user_id',function(error,result,fields){
     //         if(error) throw error;
     //         const user_id = result[0];
     //         console.log(result[0]);
     //         //login come from pasport
     //         req.login(user_id,function(error){
     //             res.redirect('/');
     //             //prompt('succesfully register!');
     //         });
     //         //res.render('customer/login', {title: 'Registration Success'});
     //     });
     //     //res.render('customer/login', {title: 'Registration Success'});
     //     console.log("success!");
     // });
     // db.query('INSERT INTO users (username, email, password) VALUES (?,?,?)',[username, email, password],
     //     function(error, results, fields) {if (error) throw error});
     // //res.render('customer/register', {title: 'Registration Success'});
     // res.redirect('/');
 });

////////////////////////////////
//this is acturally login page post
function generateToken(req, res, next) {
    console.log("this is user id");
    console.log(req.user.user_id);
    console.log("ahhdh");
    req.token = jwt.sign({
        id: req.user.user_id,
    }, 'server secret', {
        expiresIn: 60 * 60
    });
    console.log(req.token);
    console.log(req.user.user_id);
    //LocalStorage.setItem("appToken", req.token);
    ///I store it in cookies
    res.cookie('auth',req.token);
    res.cookie('user_id',req.user.user_id);
    next();
}

function respond(req, res) {
     // res.status(200).json({
     //     userid: req.user.user_id,
     //     token: req.token
     // });
    res.redirect('/customer/profile');
}
// function serialize(req, res, next) {
//     db.updateOrCreate(req.user, function(err, user){
//         if(err) {return next(err);}
//         // we store   the updated information in req.user again
//         req.user = {
//             id: user.id
//         };
//         next();
//     });
// }
router.post('/',passport.authenticate('local',{
    //successRedirect:'/profile',
    //failureRedirect:'/login/fail'
    session: false
}),generateToken,respond);
////////////////////////////////
// router.post('/', function(req, res, next){
//     const errors = req.validationErrors();
//     if (errors) {
//         console.log(`errors: ${JSON.stringify(errors)}`);
//         res.render('customer/register', {
//             title: 'Registration Fails!',
//             errors: errors
//         });
//     }
//     const email = req.body.email;
//     const password = req.body.password;
//     const username = req.body.username;
//     const db = require('../db.js');
//
//     db.query('INSERT INTO user_new (username, email, password) VALUES (?,?,?)',[username, email, password],
//         function(error, results, fields) {if (error) throw error});
//     //res.render('customer/register', {title: 'Registration Success'});
//     //res.redirect('/login');
//     db.query('SELECT LAST_INSERT_ID() as user_id',function(error,result,fields){
//         if(error) throw error;

//         const user_id = result[0];
//         console.log(result[0]);
//         //login come from pasport
//         req.login(user_id,function(error){
//             res.render('customer/login', {title: 'Registration Success'});
//         });
//         //res.render('customer/login', {title: 'Registration Success'});
//     });
//     //res.render('customer/login', {title: 'Registration Success'});
//     console.log("success!");
// });
//this is to confirm the passport
//each time store login will use this
//thses two involves session

//1108 comment
// passport.serializeUser(function(user_id, done) {
//     done(null, user_id);//write thigns when session is persistent to the session
// });
//each time fetch
// passport.deserializeUser(function(user_id, done) {
// //no erro variable//retrieve from user session
//     //done(err, user_id);
//     done(null, user_id);//null should be error take place or null
// });
//this is when author is authenticated after login which is a middleware will be used in
//comment out 1108
// function authenticationMiddleware () {
//     return (req, res, next) => {
//         console.log(`req.session.passport.user: ${JSON.stringify(req.session.passport)}`);
//
//         if (req.isAuthenticated()) return next();
//         res.redirect('/')
//     }
// }
module.exports = router;
