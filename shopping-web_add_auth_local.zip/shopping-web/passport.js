// var session = require('express-session');
//
// var passport = require('passport');
// var LocalStrategy = require('passport-local');
// var bcrypt = require('bcrypt');
// var MySQLStore = require('express-mysql-session')(session);
//
//
// passport.use(new LocalStrategy(
//     function(username, password, done) {
//         console.log(password);
//         console.log(username);
//         //must compare with db passwaord and name
//         //return done(null, 'default string is success');
//         //return done(null, false);//if false is replced with a 'string ' it is considered always successful
//         const db = require('./db');
//         db.query('SELECT id, password FROM new_user WHERE username = ?',[username],function(error,results, fields){
//             if(error){
//                 //done(error)
//                 done(error);};//done is from passport taken care of by passport
//             if(results.length === 0){//must be ===
//                 return done(null,false);//tell the user the authentication is unsuccessful
//                 //********must add return
//             }else{
//                 const hash = results[0].password.toString();
//                 //database passwordonly 46
//                 //new hash is longer thaa60
//                 console.log(hash);
//                 //password is original password
//                 console.log(password);
//                 bcrypt.compare(password,hash,function(err,response){
//                     if(response === true){ //database must be 1000
//                         console.log("match");
//                         return done(null,{user_id:results[0].id});//'safdadf');//HACE STRING COUNTE AS SUCCESFULL
//                     }else{
//                         console.log("notmatch");
//                         return done(null,false);}
//                 });
//             }
//             //const hash = results[0].password.toString().substring(0,46);
//             //return done(null,'sajfldad'); //any string indicating this is successfulcle login
//         })
//     }
// ));