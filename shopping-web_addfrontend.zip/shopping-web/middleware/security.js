const express = require('express');
const router  = express.Router();
const jwt = require('jsonwebtoken');

module.exports = (req,res,next)=>{
    try {

        //console.log(req.token);
        //token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiaWF0IjoxNTQxNjk3ODc2LCJleHAiOjE1NDE3MDE0NzZ9.FWR3Xj1TnH3Rdij1MLcA-oO5azquJM7e-yTr27uf_GA';
        //TO TACKLE THE PROBLEM W name: 'JsonWebTokenError', message: 'jwt must be provided' }
        //const token = req.body.token;
        //console.log(req);
        console.log(req.cookies.auth);
        console.log(req.LocalStorage);
        var token = req.cookies.auth;
        const decoded = jwt.verify(token, 'server secret');
        next();
    }catch(error){
        console.log(error);
        return res.status(401).json({
            message:'Auth failed'
        });
    }
};