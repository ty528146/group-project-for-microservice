const express = require('express');
const router  = express.Router();
const jwt = require('jsonwebtoken');

module.exports = (req,res,next)=>{
    try {
        console.log("#######this is header #######");
        //console.log(JSON.stringify(req.headers)["Authorization"]);
        // console.log(JSON.stringify(req.headers));
        const token = req.headers.authentication;
        console.log(token);
        const decoded = jwt.verify(token, 'server secret');
        const de_token = jwt.decode(token);
        console.log("this is decoded token");
        console.log(decoded);
        req.userid = de_token.id;
        next();
    }catch(error){
        console.log(error);
        console.log("this is a big error");
        res.redirect('/');
    }
};