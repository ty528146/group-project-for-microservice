Stripe.setPublishableKey('pk_test_fVeQffpdD9SsQgtmm83Xf2uU');
var $form = $('#checkout-form');

$form.submit(function(event) {
    $form.find('button').prop('disabled',true);
    Stripe.card.createToken({
        number: $('#card-number').val(),
        cvc: $('#card-cvc').val(),
        exp_month: $('#card-expiry-month').val(),
        exp_year: $('#card-expiry-year').val(),
        name: $('#card-name').val()
    }, stripeResponseHandler);
    return false;
});

function stripeResponseHandler(status, response){
    if (response.error) { //error happens
        $('#charge-error').text(response.error.message);
        $('#charge-error').removeClass('hidden');
        $form.find('button').prop('disabled',false); //re-enable submission
    } else { //token created
        // get the token id
        var token = response.id;
        //insert the token into the form to get submitted to the server
        $form.append($(' <input type = "hidden" name = "stripeToken"/>').val(token));
        //submit the form
        $form.get(0).submit();
    }
}