var express = require('express');
var router = express.Router();

var passport = require('passport');
var flash=require("connect-flash");
var Cart = require('../models/cart');

const bcrypt = require('bcrypt');
const https = require('https');
const saltRounds = 10;
const jwt = require('jsonwebtoken');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
/* GET home page. */
const sns = require('../middleware/notification');
const url = require('url');

const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://yh2866:Aa123456@cluster0-5mcg4.mongodb.net/shopping?retryWrites=true";

router.get('/', function(req, res, next) {
    var successMsg = req.flash('success')[0];
    var xhr = new XMLHttpRequest();
    function reqListener() {
        console.log(this.status);
        if (this.status == 200) {
            var result = JSON.parse(this.responseText);
            var productChunks = [];
            var chunkSize = 3;
            for (var i=0; i<result.length; i+=chunkSize) {
                productChunks.push(result.slice(i, i+chunkSize));
            }
            res.render('shop/index', { title: 'Quick Shopping', products: productChunks, successMsg: successMsg, noMessage: !successMsg});
        } else {
            res.redirect('/customer/profile');
        }
    }
    xhr.addEventListener("load", reqListener);
    xhr.open("GET", 'https://m93gck1ek0.execute-api.us-east-2.amazonaws.com/dev/getproduct');
    xhr.send();
});

router.get('/search', function(req, res, next){
    console.log("************Come to query**********");
    const content = req.query['content'];
    var successMsg = req.flash('success')[0];

    var xhr = new XMLHttpRequest();
    function searchContentListener() {
        // console.log(this.status);
        if (this.status == 200) {
            var result = JSON.parse(this.responseText);
            // console.log(result);
            var productChunks = [];
            var chunkSize = 3;
            const products = result.hits.hits;
            for (var i=0; i<products.length; i+=chunkSize) {
                var lineChunks = [];
                for(var j = i; j < i + chunkSize && j < products.length; j++){
                    lineChunks.push(products[j]['_source']);
                }
                // console.log(lineChunks);
                productChunks.push(lineChunks);
            }
            // console.log(productChunks);
            if(productChunks.length == 0){
                res.redirect('/');
            }else{
                res.render('shop/index', { title: 'Quick Shopping', products: productChunks, successMsg: successMsg, noMessage: !successMsg});
            }
        } else {
            res.redirect('/customer/profile');
        }
    }
    xhr.addEventListener("load", searchContentListener);
    xhr.open("GET", 'https://search-ms-shopping-domain-mvjg7sdqy3hm6ozf23fzn4qiwe.us-east-1.es.amazonaws.com/products/_search?q=title:' + content);
    xhr.send();
});

router.get('/reduce/:userid/:pid', function(req, res, next) {
    var productId = req.params.pid;
    var userid = req.params.userid;

    var xhr = new XMLHttpRequest();
    xhr.open("POST", 'https://m93gck1ek0.execute-api.us-east-2.amazonaws.com/fun/testthis');
    var sendData = {"uid": userid, "pid":productId, "action": "minus"};
    xhr.send(JSON.stringify(sendData));

    var cart = new Cart(req.session.cart ? req.session.cart : {});
    cart.reduceByOne(productId);
    req.session.cart = cart;
    res.redirect('/customer/cart/'+userid);
});

router.get('/add/:userid/:pid', function(req, res, next) {
    var productId = req.params.pid;
    var userid = req.params.userid;
    var xhr = new XMLHttpRequest();
    xhr.open("POST", 'https://m93gck1ek0.execute-api.us-east-2.amazonaws.com/fun/testthis');
    var sendData = {"uid": userid, "pid":productId, "action": "add"};
    xhr.send(JSON.stringify(sendData));

    var cart = new Cart(req.session.cart ? req.session.cart : {});
    cart.addByOne(productId);
    req.session.cart = cart;
    res.redirect('/customer/cart/'+userid);
});

router.get('/remove/:userid/:pid', function(req, res, next) {
    var productId = req.params.pid;
    var userid = req.params.userid;

    var xhr = new XMLHttpRequest();
    xhr.open("POST", 'https://m93gck1ek0.execute-api.us-east-2.amazonaws.com/fun/testthis');
    var sendData = {"uid": userid, "pid":productId, "action": "delete"};
    xhr.send(JSON.stringify(sendData));

    var cart = new Cart(req.session.cart ? req.session.cart : {});
    cart.removeItem(productId);
    req.session.cart = cart;
    res.redirect('/customer/cart/'+userid);
});

router.get('/customer/cart/:id', function(req, res, next){
    res.render('customer/cartWithOutContent');
});

router.get('/login', function(req, res, next) {
    res.render('customer/login', {
        message: req.flash('error')
    })
});



router.get('/customer/register', function(req, res, next){
    res.render('customer/register', { balala: 'Registration'});
});

//Register post
router.post('/customer/register', function(req, res, next){
    req.checkBody('email', 'email cannot be empty').notEmpty();
    req.checkBody('username', 'Username field cannot be empty.').notEmpty();
    req.checkBody('username', 'Username must be between 4-15 characters long.').len(4, 15);
    req.checkBody('email', 'The email you entered is invalid, please try again.').isEmail();
    req.checkBody('email', 'Email address must be between 4-100 characters long, please try again.').len(4, 100);
    req.checkBody('password', 'Password must be between 8-100 characters long.').len(8, 100);
    req.checkBody("password", "Password must include one lowercase character, one uppercase character, a number.").matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/, "i");
    req.checkBody('passwordMatch', 'Re-Password must be between 8-100 characters long.').len(8, 100);
    req.checkBody('passwordMatch', 'Passwords do not match, please try again.').equals(req.body.password);

    const errors = req.validationErrors();
    if (errors) {
        console.log(`errors: ${JSON.stringify(errors)}`);
        res.render('customer/register', {
            //title: 'Registration Fails!',
            errors: errors
        });
    }
   else {
       const email = req.body.email;
       const password = req.body.password;
       const username = req.body.username;
       const db = require('../db.js');

       db.query('SELECT id FROM customers WHERE (username = ?)', [username],
           function (error, results, fields) {
              if(error) throw error;
              if(results.length !== 0) {
                  res.render('customer/register', {info: 'Username already exist'
                  });
              }
              else {
                  db.query('SELECT id FROM customers WHERE (email = ? AND provider = ?)', [email, 'local'],
                      function (error, results, fields) {
                          if(error) throw error;
                          if(results.length !== 0) {
                              res.render('customer/register', {info: 'Email address already exist'
                              });
                          }
                          else {
                              bcrypt.hash(password, saltRounds, function (err, hash) {
                                  db.query('INSERT INTO customers (username, email, password, provider) VALUES (?,?,?,?)', [username, email, hash, 'local'],
                                      function (error, results, fields) {
                                          if (error) {
                                              throw error;
                                          }
                                          // res.redirect('/');
                                      });
                                  db.query('SELECT LAST_INSERT_ID() as user_id', function(error, results, fields) {
                                      if(error) throw error;
                                      const user_id = results[0];
                                      console.log(results[0]);

                                      //Email Verification
                                      var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
                                      var xhr = new XMLHttpRequest();
                                      xhr.open('POST', 'https://kpnxu8rtfd.execute-api.us-east-1.amazonaws.com/prodd/');
                                      xhr.setRequestHeader('Content-Type', 'application/json');

                                      const payload = {
                                          id: user_id,
                                          username: username,
                                          email: email,
                                          role: "user"
                                      };

                                      const secretToken = jwt.sign(JSON.stringify(payload), "send-email-secret");

                                      console.log("secretToken" + secretToken);
                                      // xhr.send(JSON.stringify({email: email, name: username, token: "https://jza7lmkph6.execute-api.us-east-1.amazonaws.com/prod?token="  + secretToken}));
                                      const eventjson = {
                                          email: email,
                                          name: username,
                                          token: "https://jza7lmkph6.execute-api.us-east-1.amazonaws.com/prod?token=" + secretToken
                                      };

                                      sns.sendEvent("CustomerRegistration", JSON.stringify(eventjson));

                                      req.login(user_id, function(err) {
                                          res.locals.isAuthenticated = true;
                                          res.render('customer/verification');
                                          //res.redirect('/customer/profile');
                                      })
                                  });
                                  //res.render('customer/register', {title: 'Registration Success'});
                              })
                          }
                      });
              }
           });
   }
 });



router.get('/customer/verification/:token', function(req, res, next){
    try {
        //console.log(req.params.token);

        const secretToken = req.params.token;
        console.log("secretToken  se c r e t To kensecretTokensecretTokensecretToken" + secretToken);

        jwt.verify(secretToken, 'verify-email-secret', function(err, decoded) {
            // console.log("id: " + decoded.id['user_id']) // bar

            // const user_id = decoded.id['user_id'];
            const user_id = decoded.id;
            console.log("user_iduser_iduser_iduser_iduser_id" + user_id);
            const db = require('../db.js');
            db.query('SELECT id FROM customers WHERE (id = ?)', [user_id],
                function (error, results, fields) {
                    if (error) throw error;

                    if (results.length !== 0 && decoded.role === "admin") {
                        //console.log(results[0].id);
                        db.query('UPDATE customers SET verified = ? WHERE (id = ?)', [1, user_id]);
                        res.render('customer/login', {
                            info: 'You have successfully activate your account! Please log in.'
                        });
                    }
                    else {
                        res.render('customer/register', {
                            info: 'The token is invalid'
                        });
                    }
                });
        });
    } catch (e) {
        //res.send('error');
        res.render('customer/register', {
            info: 'The token is invalid'
        });
    }
});

router.get('/auth/facebook', passport.authenticate('facebook'));

router.get('/auth/facebook/callback', passport.authenticate('facebook', { failureRedirect: '/login' }),
    function(req, res) {
        res.redirect('/customer/redirect');
    });

router.get('/auth/twitter', passport.authenticate('twitter'));

router.get('/auth/twitter/callback', passport.authenticate('twitter', {failureRedirect: '/login'}),
    function(req, res) {
        var id = req.user.userid;
        console.log(req.user.userid);
        res.redirect('/customer/redirect/'+id);
    });

router.get('/customer/redirect/:id',function(req,res){
    console.log('************This is redirect req************');
    console.log(req.params.id);
    req.token = jwt.sign({
        id: req.params.id,
    }, 'server secret', {
        expiresIn: 60 * 60
    });
    console.log(req.token);
    res.render('customer/redirect', { token:req.token, userid:req.params.id});
});

router.get('/customer/profile/:id',function(req,res,next){
    console.log("********This is req*********");
    // console.log(req);
    res.render('customer/profile');
});


router.get('/customer/profileOrders',function(req,res,next){
    res.render('customer/profileOrders')
});


//Passport serialize and deserialize
passport.serializeUser(function(user_id, done) {
    done(null, user_id);
});
passport.deserializeUser(function(user_id, done) {
    done(null, user_id);
});

function generateToken(req, res, next) {
    req.token = jwt.sign({
        id: req.user.userid,
    }, 'server secret', {
        expiresIn: 60 * 60
    });
    console.log("this is the process of generating token");
    res.setHeader('Content-Type', 'application/json');
    return res.send(JSON.stringify({ token: req.token,userid:req.user.userid}));
    next();
}

function respond(req, res) {
    console.log("this is the print token inside respond");
    // console.log(req.token);
    const id = req.userid;
    res.redirect('/customer/profile' + id);
}

router.post('/login',passport.authenticate('local',{
    session: false
}),generateToken,respond);

module.exports = router;
