var express = require('express');
var router = express.Router();
const checkAuth = require('../middleware/security');
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
var Cart = require('../models/cart');
router.get('/logout', function(req, res, next){
    req.logout();
    req.session.destroy();
    res.redirect('/');
});

var uuser_id;

const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://yh2866:Aa123456@cluster0-5mcg4.mongodb.net/shopping?retryWrites=true";

router.get('/cartAuth/:id', checkAuth, function(req, res, next){
    console.log("this is the header from front end ");
    try{
        // var cart = new Cart(req.session.cart ? req.session.cart : {});
        var uid = req.params.id;
        console.log("this is userid"+uid)
        console.log(uid);
        var xhr = new XMLHttpRequest();
        xhr.open("POST", 'https://m93gck1ek0.execute-api.us-east-2.amazonaws.com/fun/getcartandprice');
        xhr.onload = function(e) {
            try {
                var cartList = JSON.parse(this.responseText).body;
                console.log(cartList);
                console.log("debug:" + cartList.items);
                console.log("debug: " + cartList.totalPrice);
                req.session.cart = cartList;
                var cart = new Cart(req.session.cart ? req.session.cart : {});
                if (!req.session.cart) {
                    return res.render('customer/cart', {products: null});
                }
                res.render('customer/cart', {products: cart.generateList(), totalPrice: cart.totalPrice});
            }catch(e){
                console.log("saaaaaaaaaad");

            }
        };
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('Authorization', 'allow');//deny//asdfjal
        xhr.send(JSON.stringify({uid:uid}));
    }
    catch(error){
        console.log(error);
    }
});

router.get('/add-to-cart/:userid/:pid', checkAuth, function(req, res, next) {
    var productId = req.params.pid;
    var userid = req.params.userid;
    console.log("userid: " + userid);
    console.log("pid:" + productId);

    var xhr = new XMLHttpRequest();
    xhr.open("POST", 'https://m93gck1ek0.execute-api.us-east-2.amazonaws.com/fun/testthis');
    var sendData = {"uid": userid, "pid":productId, "action": "add"};
    xhr.send(JSON.stringify(sendData));

    var cart = new Cart(req.session.cart ? req.session.cart : {});
    var xhr1 = new XMLHttpRequest();
    function onreadystatechange() {
        if (this.status === 200) {
            var product = JSON.parse(this.responseText);
            console.log("status：" + this.status);
            console.log("result：" + this.responseText);
            cart.add(product, productId);
            req.session.cart = cart;
            res.redirect('/');
        } else {
            res.redirect('/');
        }
    }
    xhr1.addEventListener("load", onreadystatechange);
    xhr1.open("POST", 'https://m93gck1ek0.execute-api.us-east-2.amazonaws.com/fun/getproduct');
    var sendData = {"pid":productId};
    xhr1.send(JSON.stringify(sendData));
});

router.get('/customer/profile/registered', checkAuth, function(req, res, next) {
});

router.get('/profile',function(req,res,next){
    res.locals.isAuthenticated = true;
    res.render('customer/profile', {title:"PROFILE succeed"});
});

router.get('/profileA',function(req,res,next){
    res.locals.isAuthenticated = true;
    res.render('customer/profileA', {title:"PROFILE succeed"});
});


router.get('/personal', checkAuth, function(req, res, next) {
    uuser_id = parseInt(req.userid);
    MongoClient.connect(uri, { useNewUrlParser: true }, function(err, client) {
        if(err) {
            console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
        }
        console.log('Connected MongoDB get ...');
        const collection = client.db("shopping").collection("personal");
        collection.findOne({id: parseInt(req.userid)}, function (error, documents) {
            res.render('customer/profilePersonal', {
                id: req.userid,
                data: documents
            });
        });
        client.close();
    });
});


router.post('/personal', function(req, res, next){
    MongoClient.connect(uri, { useNewUrlParser: true }, function(err, client) {
        if(err) {
            console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
        }
        console.log('Connected MongoDB...');
        const collection = client.db("shopping").collection("personal");
        collection.update(
            {id: parseInt(req.body.user_id)},
            {
                id: parseInt(req.body.user_id),
                first_name: req.body.first,
                last_name: req.body.last,
                phone_number: req.body.phone
            },
            {upsert: true}
        );
        client.close();
    });
    res.redirect('/customer/profile');
});


router.get('/address', function(req, res, next) {
        MongoClient.connect(uri, { useNewUrlParser: true }, function(err, client) {
        if(err) {
            console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
        }
        console.log('Connected MongoDB get ...');
        const collection = client.db("shopping").collection("address");
        collection.findOne({id: uuser_id}, function (error, documents) {
            res.render('customer/profileAddress', {
                id: uuser_id,
                data: documents
            });
        });
        client.close();
    });
});

router.post('/address', function(req, res, next) {
    MongoClient.connect(uri, { useNewUrlParser: true }, function(err, client) {
        if(err) {
            console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
        }
        console.log('Connected MongoDB...');
        const collection = client.db("shopping").collection("address");
        collection.update(
            {id: uuser_id},
            {
                id: uuser_id,
                street: req.body.street,
                country: req.body.country,
                state: req.body.state,
                city: req.body.city,
                zip: req.body.zip
            },
            {upsert: true}
        );
        client.close();
    });
    res.redirect('/customer/address')
});


router.get('/checkout', function(req, res, next) {
    if (!req.session.cart) {
        return res.render('customer/cart', {products:null});
    }
    var cart = new Cart(req.session.cart);
    var errMsg = req.flash('error')[0];

    var doc;
    MongoClient.connect(uri, { useNewUrlParser: true }, function(err, client) {
        if(err) {
            console.log('Error occurred while connecting to MongoDB Atlas...\n',err);
        }
        console.log('Connected MongoDB get ...');
        const collection = client.db("shopping").collection("personal");
        collection.findOne({id: uuser_id}, function (error, documents) {
            doc = documents;
        });

        const collection2 = client.db("shopping").collection("address");
        collection2.findOne({id: uuser_id}, function (error, documents) {
            res.render('customer/checkout', {products: cart.generateList(),
                total: cart.totalPrice,
                id: uuser_id,
                data: doc,
                address: documents,
                errMsg: errMsg,
                noError: !errMsg});
        });
        client.close();
    });
});
router.post('/checkout', function(req, res, next) {

    res.redirect('/customer/checkout');
});

//
// router.post('/checkout', function(req, res, next) {
//     if (!req.session.cart) {
//         return res.render('customer/cart', {products:null});
//     }
//     var cart = new Cart(req.session.cart);
//     var stripe = require("stripe")("sk_test_nHDxkTP1upwFQBr0Fw0nj62E");
//
//     stripe.charges.create({
//         amount: cart.totalPrice * 100,
//         currency: "usd",
//         source: req.body.stripeToken, // obtained with Stripe.js
//         description: "Charge for QuickShopping."
//     }, function(err, charge) {
//         // asynchronously called
//         if (err) {
//             req.flash('error', err.message);
//             return res.redirect('/customer/checkout');
//         }
//         req.flash('success', 'Your purchase is successful!');
//         req.session.cart=null;
//         res.redirect('/');
//     });
// });
function checkout(req, res, next) {

    if (!req.session.cart) {
        return res.render('customer/cart', {products:null});
    }
    var cart = new Cart(req.session.cart);
    var stripe = require("stripe")("sk_test_nHDxkTP1upwFQBr0Fw0nj62E");

    stripe.charges.create({
        amount: cart.totalPrice * 100,
        currency: "usd",
        source: req.body.stripeToken, // obtained with Stripe.js
        description: "Charge for QuickShopping."
    }, function(err, charge) {
        // asynchronously called
        if (err) {
            req.flash('error', err.message);
            return res.redirect('/customer/checkout');
        }

        req.flash('success', 'Your purchase is successful!');
        // var xhr = new XMLHttpRequest();
        // xhr.open("POST", 'https://m93gck1ek0.execute-api.us-east-2.amazonaws.com/fun/testthis');
        // var sendData = {"uid": ""+uuser_id, "pid":"", "action": "rmall"};
        // xhr.send(JSON.stringify(sendData));
        // console.log("userid who would be removed all the products: "+uuser_id);
        // req.session.cart=null;
        next();
    });
}

router.get('/profileOrdersAuth', checkAuth, function(req, res, next){
    defaultdata =  {
        username:"none",
        zipcode: "none",
        address1:"none",
        address2:"none",
        state:"none",
        city: "none",
        paymentid:"none",
        id: uuser_id
    };
    console.log("this is the header from front end ");
    console.log(req.headers);
    try{
        var uid = req.userid;
        console.log(uid);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'https://glllvyedha.execute-api.us-east-1.amazonaws.com/dev/compare-yourself/ordersummary');
        xhr.onload = function(e) {
            try {
                if (this.status == 200){
                    var result = JSON.parse(this.responseText);
                    if (result.statusCode == 200) {
                        var data = result.data;
                        console.log(data);
                        res.render('customer/profileOrdersAuth', {data:data,
                                                                  id: uuser_id});
                        console.log("successssssssssssss")
                    }
                    else if(this.errorMessage != "npt null"){
                        res.render('customer/profileOrdersAuth', defaultdata);
                    }
                }
            }catch(e){
                console.log("saaaaaaaaaad");
                res.render('customer/profileOrdersAuth', defaultdata);
            }
        };
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('Authorization', 'allow');//deny//asdfjal
        xhr.send(JSON.stringify({userid:uid}));
    }
    catch(error){
        console.log(error);
    }
});


router.post('/shipping', checkout,function(req, res, next) {
    try{
        console.log("this is for testing shipping");
    }
    catch(error){
        console.log("============this is user error========");
        console.log(error);
    }
    console.log(req.body);
    console.log(req.session.cart);
    var products = req.session.cart;
    var array = '';
    for (var id in products.items) {
        var product = products.items[id];
        var singleItem = product.item.title + ': ' +  product.qty + ' unit(s);  ';
        array += singleItem;
    }
    // array += 'Total Price: ' + products.totalPrice;
    var add2;
    if(req.body.address2.length === 0){
        add2 = '';
        // address2 = array;
    }
    else{
        add2 = ', '+req.body.address2;
        // address2 = array;
    }
    var uid = ''+uuser_id;
    var d = new Date();
    var paymentid = d.getDate()+"-"+(d.getMonth() + 1)+"-"+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds();
    var username ="none";
    address1 = array;
    address2 = products.totalPrice;
    city = req.body.address1 + add2;
    state= req.body.city + ',  ' + req.body.state;
    zipcode = req.body.zip;
    username = req.body.receiverName;
    var xhr = new XMLHttpRequest();
    console.log("this is age"+address1);
    xhr.open('POST', 'https://glllvyedha.execute-api.us-east-1.amazonaws.com/dev/compare-yourself/shipping');
    xhr.onload = function(e) {
        if (this.status == 200) {
            var result = JSON.parse(this.responseText);
            console.log(typeof(result));
            console.log('this is  #########result###########');
            console.log(uid);
            console.log(result);
            res.redirect('/');
        }
    };
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('Authorization', 'allow');//deny//asdfjal
    console.log(
        {
            address1:address1,
            address2:address2,
            username:username,
            state:state,
            city:city,
            zipcode:zipcode,
            userid:uid,
            paymentid:paymentid
        }
    );
    xhr.send(JSON.stringify({
        address1:address1,
        address2:address2,
        username:username,
        state:state,
        city:city,
        zipcode:zipcode,
        userid:uid,
        paymentid:paymentid
    }));
    var xhr1 = new XMLHttpRequest();
    xhr1.open("POST", 'https://m93gck1ek0.execute-api.us-east-2.amazonaws.com/fun/testthis');
    var sendData = {"uid": ""+uuser_id, "pid":"", "action": "rmall"};
    xhr1.send(JSON.stringify(sendData));
    console.log("userid who would be removed all the products: "+uuser_id);
    req.session.cart=null;

});

module.exports = router;
