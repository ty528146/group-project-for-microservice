const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
var bcrypt = require('bcrypt');
const passportJWT = require("passport-jwt");
const JWTStrategy   = passportJWT.Strategy;
const ExtractJWT = passportJWT.ExtractJwt;
var FacebookStrategy = require('passport-facebook').Strategy;
var TwitterStrategy = require('passport-twitter').Strategy;
//Login authentication
passport.use(new LocalStrategy({
        usernameField: 'username',
        passwordField: 'password',
        passReqToCallback: true,
        session: false
    },
    function(req, username, password, done) {
        console.log(username);
        console.log(password);

        const db = require('./db.js');
        db.query('SELECT id, password, verified FROM customers WHERE username = ? OR email = ?', [username, username],
            function(err, results, fields) {
                if(err) {
                    console.log("111111111");
                    req.flash('error', "Database error");
                    return done(null, false)
                };
                if(results.length === 0) {
                    console.log("22222222");
                    req.flash('error', "Username or email doesn't exist");
                    return done(null, false);
                }
                if(!results[0].verified) {
                    console.log("333333");
                    req.flash('error', "Email is not verified! Please check your email for verification.");
                    return done(null, false);
                }
                console.log(results[0].password.toString());
                const hash = results[0].password.toString();
                bcrypt.compare(password, hash, function (err, response) {
                    if(response === true) {
                        //res.locals.isAuthenticated = true;
                        return done(null, {userid:results[0].id});
                    }
                    else {
                        console.log("44444444");
                        req.flash('error', "Username or password is incorrect");
                        return done(null, false);
                    }
                });
            });
    }
));

passport.use(new FacebookStrategy({
        clientID: 345228269559821,
        clientSecret: '8ae10ea83e9bb42c9d2dc1024859fea9',
        callbackURL: "http://localhost:3000/auth/facebook/callback"
    },
    function(accessToken, refreshToken, profile, cb) {
        return cb(null, profile);
    }
));

passport.use(new TwitterStrategy({
        consumerKey:'gq0GwpR88N2AyfHrlqxBm3fHC',
        consumerSecret: 'AFivnc0K8I7lM8g8YdDi9Oc8YkbiX4SX9VjqGNurk3DmAjIkyi',
        callbackURL: "http://shoppingweb-envllll.kdug7qixtz.us-east-1.elasticbeanstalk.com/auth/twitter/callback"
        // callbackURL: "http://localhost:3000/auth/twitter/callback"
    },
    function(token, tokenSecret, profile, cb) {
        const username = profile.id;
        const hash = 'twitter';
        const email = 'twitter';
        const db = require('./db.js');
        console.log("********Passport************");
        db.query('SELECT id FROM customers WHERE provider = ? AND username = ?', ['twitter', username],
            function (error, results, fields) {
                if(error) throw error;
                if(results.length !== 0) {
                    return cb(null, {userid:results[0].id});
                }
                else {
                    console.log("!!!!!!!!!!!!!!!!");
                    db.query('INSERT INTO customers (username, email, password, provider) VALUES (?,?,?,?)', [username, email, hash, 'twitter'],
                        function (error, results, fields) {
                            if (error) {
                                throw error;
                            }
                            // console.log(results);
                            return cb(null, {userid:results[0].id});
                        });
                }
            });
    }
));


