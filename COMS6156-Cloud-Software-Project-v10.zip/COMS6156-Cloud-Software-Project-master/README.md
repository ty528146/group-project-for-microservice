# COMS6156-Cloud-Software-Project


## Group Members:
|UNI     |       Name             |           Email        |
| ------ |  -------------------   |   ---------------------|
|ac4218  |   Anlu Chen            | ac4218@columbia.edu    |
|yz3167  |   Yamei Zhu            | yz3167@columbia.edu    |
|cw3122  |  Chengrui Wu           | cw3122@columbia.edu    |
|yh2866  |   Yuanqing Hong        |  yh2866@columbia.edu   |
|yt2583  |     Yuan Tian          |  yt2583@columbia.edu   |


## For Beanstalk:
Please uninstall the bcrypt package with this command: `npm uninstall bcrypt --save`

And then add `"bcrypt": "^3.0.2"` to the file package.json

The reason is the bcrypt package version for MacOS and Linux is not compatiable. Therefore, we need to remove the local bcrypt from node_module first, and then let the beanstalk itself to install the package in the Linux.

## How to run:

### 1. `npm install`

### 2. `npm start`

note: you may have this error: [Expected in: flat namespace](https://github.com/kelektiv/node.bcrypt.js/issues/656)

running `npm rebuild bcrypt --build-from-source` to fix this problem

### Reference:
#### Tutorial1: https://www.youtube.com/watch?v=-3vvxn78MH4&index=2&list=PL55RiY5tL51rajp7Xr_zk-fCFtzdlGKUp
#### Tutorial2: https://www.youtube.com/watch?v=gYjHDMPrkWU&list=PLpPnRKq7eNW3Qm2OfoJ3Hyvf-36TulLDp
